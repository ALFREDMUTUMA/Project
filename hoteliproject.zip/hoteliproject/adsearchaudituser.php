<?php
include_once './classes.php';
$q = $_GET["q"];
$permission = "searchaudituser";
usersearch($q);

?>